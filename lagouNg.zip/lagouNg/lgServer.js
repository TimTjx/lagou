var express = require("express");
var exprerss_static = require("express-static");
var fs = require("fs")
var server = express();
var mysql = require("mysql");
//配置参数
var db = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"123456",
    database:"lagou"
})
//链接数据库
db.connect();


server.get("/",(request,response)=>{
    var data = fs.readFileSync("./web/index.html");
    // var data = String(data);//数据正解析
    // response.send(data)
    response.end(data)
})


server.get("/data",(request,response)=>{
    db.query("SELECT * FROM lagouwang",(error,data)=>{
        if(error){
            console.log(error);
        }else{
            console.log(data);
            response.send(data)
        }

    })
})



server.use(exprerss_static("./web"))
server.listen(333);
