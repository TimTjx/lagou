var myApp = angular.module("myApp",["ngAnimate","ngRoute"]);
myApp.config(["$routeProvider",($routeProvider)=>{
    $routeProvider.when("/job",{
        templateUrl:"job.html",
        controller : "job"
    })
    $routeProvider.when("/search",{
        templateUrl:"search.html",
        controller : "search"
    })
    $routeProvider.when("/my",{
        templateUrl:"my.html",
        controller : "my"
    })
}])


myApp.controller("job",($scope,$http)=>{
//    $http.get("http://172.16.10.122:333/data").then((data)=>{
   $http.get("http://192.168.1.128:333/data").then((data)=>{
       console.log(data.data);
       $scope.data = data.data
   })
})
myApp.controller("search",($scope)=>{
    $scope.search = "搜索"
})
myApp.controller("my",($scope)=>{
    $scope.my = "我的"
})

myApp.controller("footerCtrl",($scope)=>{
    $scope.jobCla = "addChange";
    $scope.clickChange = (url)=>{
        $scope.jobCla = "";
        $scope.searchCla = "";
        $scope.myCla = "";
        switch(url)
        {
            case "job":
            $scope.jobCla = "addChange";
            break;
            case "search":
            $scope.searchCla = "addChange";
            break;
            case "my":
            $scope.myCla = "addChange";
            break;
        }
    }
})
